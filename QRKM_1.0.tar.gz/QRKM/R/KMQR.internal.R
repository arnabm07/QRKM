KMQR.internal <-
function(Y, K, Z, tau, lambda) {
## Kernel machine quantile regression
## X nonparamteric var (nxp)
## Z parametric var (nxq)
## Y response var (nx1)
## tau quantile
## lambda penalty par

n = nrow(Y)
q = ncol(Z)
Dmat = K + (det(K)==0)*(10^(-10)*diag(1,nrow(K)))
dvec = lambda*Y
Amat = cbind(rep(1,n), Z, diag(1,n), diag(-1,n))
bvec = c(0, rep(0,q), rep(tau-1,n), rep(-tau,n))
QPsolution = solve.QP(Dmat, dvec, Amat, bvec, meq=q+1)
thetasolve = QPsolution$solution

if (sum(is.finite(thetasolve))<n) {
error("no finite solution reached")
}

if (sum(is.finite(thetasolve))==n){
# estimate of f without the intercept part 
nointest = K%*%thetasolve/lambda
newy = Y-nointest
quantresult = rq(newy~Z, tau=tau) 
parametersolve = quantresult$coefficients
}

# solution for beta0
finalbeta0 = parametersolve[1]
# solution for beta
finalbeta = parametersolve[2:(q+1)]
return(list(beta0 = finalbeta0, beta = finalbeta, fest = nointest, lambda = lambda, resid = Y - finalbeta0 - Z%*%finalbeta - nointest))
}
