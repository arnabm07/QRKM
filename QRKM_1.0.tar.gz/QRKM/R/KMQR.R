KMQR <-
function(Y, X, Z, tau, lambda.grid=10^seq(-3,3, len=30), nboot = 50)
{
## Kernel machine quantile regression
## X nonparamteric var (nxp)
## Z parametric var (nxq)
## Y response var (nx1)
## tau quantile

## Check function
check.fn = function(rr, tau){return( (tau - (rr<0))*rr  ) }

n = nrow(Y)
q = ncol(Z)
K = IBS.kernel(X) ##kernel matrix
boot.covariance.trace = rep(NA, length(lambda.grid))
lambda.opt = NA
beta.cov.mat = numeric(0)
opt.crit = 99999
for (lam in 1:length(lambda.grid)){
qres = try(KMQR.internal(Y, K, Z, tau, lambda.grid[lam])) ## estimates
      if(class(qres)!="try-error"){
## doing bootstrap (pairs w replacement)
int.boot = rep(NA, nboot)
beta.boot = matrix(NA, nrow=nboot, ncol=q)
bn = 1
while(bn < (nboot+1)){

ind = sample(n, replace=T)
Yboot = matrix(Y[ind,], ncol=1)
#Xboot = X[ind,]
Kboot = K[ind,ind]
Zboot = Z[ind,]


qres.boot = try(KMQR.internal(Yboot, Kboot, Zboot, tau, lambda.grid[lam]), silent = T)
if(class(qres.boot)!="try-error"){
int.boot[bn] = qres.boot$beta0
beta.boot[bn,] = qres.boot$beta
bn = bn + 1
}
}

comb.boot = cbind(matrix(int.boot, ncol=1), beta.boot)
boot.est = apply(comb.boot, 2, mean) 

tmp = comb.boot - matrix(1, nrow=nboot)%*%matrix(c(qres$beta0, qres$beta), nrow=1)

covest.boot = t(tmp)%*%tmp/nboot
boot.covariance.trace[lam] = sum(diag(covest.boot))

if(boot.covariance.trace[lam] + mean(check.fn(qres$resid, tau)) < opt.crit){
opt.crit = boot.covariance.trace[lam] + mean(check.fn(qres$resid, tau))
beta.cov.mat = covest.boot
lambda.opt = lambda.grid[lam]
qres.opt = qres
}
}
if (class(qres)=="try-error"){
}}
return(list(result = qres.opt, beta.cov.mat=beta.cov.mat, lambda.opt = lambda.opt, opt.crit=opt.crit))
}
