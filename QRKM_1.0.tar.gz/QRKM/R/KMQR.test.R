KMQR.test <-
function(Y, X, Z, tau, simrep=1000){

K = IBS.kernel(X) ##kernel matrix
n=length(Y)
y=Y
quantresult<-rq(y~Z, tau=tau) 
parametersolve<-quantresult$coefficients
residual<-quantresult$residuals

w<-rep(0,n)
for (i in 1:n) {
if (residual[i]==0)
residual[i]<-rbinom(1,1,1-tau)-0.5
w[i]<-tau-(residual[i]<0)
}
T<-t(w)%*%K%*%w#### observed QRKM test statistic
res = try(KMQR(t(t(y)), X, Z, tau, lambda.grid=10^seq(-2,2, len=20), nboot = 50), silent=F)
predictyy = res$result$fest + res$result$beta0 + Z%*%res$result$beta
fullresidual<-y-predictyy 
intercept.est = res$result$beta0 + mean(res$result$fest)
beta.est =  res$result$beta
betasd.est = sqrt(diag(res$beta.cov.mat))
h.est= res$result$fest - mean(res$result$fest)
optimallambda<-res$lambda.opt     
Tsim<-rep(NA,simrep)
for (tt in 1:simrep){
randomindex<-sample(n)
simresidual<-fullresidual[randomindex]
simy<-y-residual+simresidual
simquantresult<-rq(simy~Z, tau=tau) 
simparametersolve<-simquantresult$coefficients
simnewresidual<-simquantresult$residuals
simw<-rep(0,n)
for (i in 1:n) {
if (simnewresidual[i]==0)
simnewresidual[i]<-rbinom(1,1,1-tau)-0.5
simw[i]<-tau-(simnewresidual[i]<0)
}
Tsim[tt]<-t(simw)%*%K%*%simw
}
tempvector<-rep(T,simrep)-Tsim
pv<-length(which(tempvector<=0))/simrep
return(pv)
}
