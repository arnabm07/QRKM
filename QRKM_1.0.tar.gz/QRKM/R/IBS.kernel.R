IBS.kernel <-
function(X) 
{
## X is the full nxp SNP matrix, n: sample size, m: number of variables
## output: nxn kernel matrix
    n = nrow(X)
    K = matrix(nrow = n, ncol = n)

    for (i in 1:n) {
        for (j in i:n) {
            K[i,j] = K[j,i] = sum(  2*(X[j,] == X[i,]) + (abs(X[j,]-X[i,])==1) )
        }
    }
    K = K/ncol(X)
    return(K)
}
